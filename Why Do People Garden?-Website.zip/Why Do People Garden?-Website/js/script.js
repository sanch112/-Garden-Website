$(document).ready(function() {

	$(".gallery").slick({ // enables slick library to .gallery div
		dots: true, // enables pagination buttons
		fade: true	// enables fade transitions between pictures
	});

});
